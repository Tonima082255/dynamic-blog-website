# from django.contrib import admin
# from .models import BlogPost

# class BlogPostAdmin(admin.ModelAdmin):
#     list_display = ('title', 'author', 'created_at', 'category')
#     search_fields = ('title', 'content', 'category')
#     list_filter = ('category', 'created_at')
#     list_editable = ('category',)
#     ordering = ('-created_at',)

# admin.site.register(BlogPost, BlogPostAdmin)

# # Register your models here.
# # blog/admin.py
# from django.contrib import admin
# from .models import BlogPost, Vlog, Comment, Like, Category

# admin.site.register(BlogPost)
# admin.site.register(Vlog)
# admin.site.register(Comment)
# admin.site.register(Like)
# admin.site.register(Category)
from django.contrib import admin
from .models import BlogPost, Vlog, Comment, Like, Category

class BlogPostAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'created_at', 'category')
    search_fields = ('title', 'content', 'category')
    list_filter = ('category', 'created_at')
    list_editable = ('category',)
    ordering = ('-created_at',)

admin.site.register(BlogPost, BlogPostAdmin)

# Register other models normally
admin.site.register(Vlog)
admin.site.register(Comment)
admin.site.register(Like)
admin.site.register(Category)

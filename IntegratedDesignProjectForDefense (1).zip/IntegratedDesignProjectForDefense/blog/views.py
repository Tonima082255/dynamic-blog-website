#from django.shortcuts import render
# Create your views here.
# views.py

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.db import IntegrityError
from django.db.models import Avg, Count
from django.views.decorators.csrf import ensure_csrf_cookie

def index(request):
    # Get latest 6 posts
    latest_posts = BlogPost.objects.all().order_by('-created_at')[:6]
    # Get 3 featured posts (you might want to add a 'featured' field to your model)
    featured_posts = BlogPost.objects.all().order_by('-created_at')[:3]
    
    return render(request, 'index.html', {
        'latest_posts': latest_posts,
        'featured_posts': featured_posts
    })

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('index')
        else:
            messages.error(request, 'Invalid login')
    return render(request, 'user_login.html')

def about(request):
    from django.db.models import Count
    from .models import BlogPost, User, Comment
    
    # Get statistics
    total_posts = BlogPost.objects.count()
    total_users = User.objects.count()
    total_comments = Comment.objects.count()
    
    # Get top categories with post counts
    categories = BlogPost.objects.exclude(category__isnull=True).exclude(category__exact='')\
        .values('category').annotate(count=Count('category')).order_by('-count')[:5]
    
    # Get recent posts
    recent_posts = BlogPost.objects.order_by('-created_at')[:3]
    
    context = {
        'total_posts': total_posts,
        'total_users': total_users,
        'total_comments': total_comments,
        'categories': categories,
        'recent_posts': recent_posts,
    }
    
    return render(request, 'about.html', context)

# from .models import BlogPost
# from django.db.models import Q

# def explore(request):
#     query = request.GET.get('q')
#     if query:
#         posts = BlogPost.objects.filter(Q(title__icontains=query) | Q(content__icontains=query))
#     else:
#         posts = BlogPost.objects.all().order_by('-created_at')
#     return render(request, 'explore.html', {'posts': posts, 'query': query})

from django.db.models import Q, Count
from django.contrib.auth import authenticate, login, get_user_model
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
import json

from .models import BlogPost, Like, Comment
from .forms import CustomUserCreationForm, BlogPostForm, VlogForm

User = get_user_model()

# def explore(request):
#     query = request.GET.get('q', '')
#     selected_category = request.GET.get('category', '')

#     categories = BlogPost.objects.values_list('category', flat=True).distinct()

#     posts = BlogPost.objects.all()
#     if query:
#         posts = posts.filter(Q(title__icontains=query) | Q(content__icontains=query))
#     if selected_category:
#         posts = posts.filter(category__iexact=selected_category)

#     return render(request, 'explore.html', {
#         'posts': posts,
#         'query': query,
#         'selected_category': selected_category,
#         'categories': categories,
#     })
def explore(request):
    query = request.GET.get('q', '')
    selected_category = request.GET.get('category', '')

    # Get all unique non-empty categories from existing posts
    posts = BlogPost.objects.all().order_by('-created_at')
    
    # Get all non-empty categories from posts
    all_categories = BlogPost.objects.exclude(category__isnull=True).exclude(category__exact='')\
        .order_by('category').values_list('category', flat=True).distinct()
    
    # Convert to a list and remove any empty strings
    all_categories = [cat for cat in all_categories if cat and cat.strip()]
    
    # If no categories found, use default ones
    if not all_categories:
        all_categories = ['Travel', 'Food', 'Tutorial', 'Daily Life', 'Tech']

    # Apply filters
    if query:
        posts = posts.filter(Q(title__icontains=query) | Q(content__icontains=query))

    if selected_category and selected_category in all_categories:
        posts = posts.filter(category__iexact=selected_category)

    # Prefetch related comments and their users for each post
    posts = posts.prefetch_related('comments__user')

    return render(request, 'explore.html', {
        'posts': posts,
        'query': query,
        'selected_category': selected_category,
        'predefined_categories': all_categories,  # Now contains actual categories from posts
    })


def user_login(request):
    if request.method == 'POST':
        email = request.POST.get('username')
        password = request.POST.get('password')

        try:
            user_obj = User.objects.get(username=email)
            user = authenticate(request, username=user_obj.username, password=password)
            
            if user is not None:
                # Ensure profile exists before login
                try:
                    user.profile
                except UserProfile.DoesNotExist:
                    UserProfile.objects.create(user=user)
                
                login(request, user)
                return redirect('dashboard')
            else:
                return render(request, 'user_login.html', {'error': 'Invalid credentials'})
        except User.DoesNotExist:
            return render(request, 'user_login.html', {'error': 'User does not exist'})

    return render(request, 'user_login.html')

@ensure_csrf_cookie
def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            try:
                user = form.save()
                # Create a profile for the new user
                from .models import UserProfile
                UserProfile.objects.create(user=user)
                
                # Log the user in
                login(request, user)
                return redirect('dashboard')
            except IntegrityError:
                form.add_error('email', 'A user with that email address already exists.')
        else:
            print('Registration form is invalid:', form.errors)
    else:
        form = CustomUserCreationForm()
    return render(request, 'register.html', {'form': form})

@login_required
def dashboard(request):
    user = request.user
    posts = BlogPost.objects.filter(author=user)
    likes = Like.objects.filter(post__author=user).count()
    comments = Comment.objects.filter(post__author=user).count()

    context = {
        'posts': posts,
        'likes': likes,
        'comments': comments,
    }
    return render(request, 'dashboard.html', context)

@login_required
def create_post(request):
    if request.method == 'POST':
        form = BlogPostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.save()
            return redirect('my_posts')
    else:
        form = BlogPostForm()
    return render(request, 'create_post.html', {'form': form})

@login_required
def upload_vlog(request):
    if request.method == 'POST':
        form = VlogForm(request.POST, request.FILES)
        if form.is_valid():
            vlog = form.save(commit=False)
            vlog.user = request.user
            vlog.save()
            return redirect('dashboard')
    else:
        form = VlogForm()
    return render(request, 'upload_vlog.html', {'form': form})

@login_required
def my_posts(request):
    posts = BlogPost.objects.filter(author=request.user)
    return render(request, 'my_posts.html', {'posts': posts})

@login_required
def view_comments(request):
    comments = Comment.objects.filter(post__author=request.user)
    return render(request, 'view_comments.html', {'comments': comments})

@login_required
def analytics(request):
    # Get user's posts
    posts = BlogPost.objects.filter(author=request.user)
    
    # Category-wise statistics
    category_stats = posts.values('category').annotate(
        post_count=Count('id'),
        total_likes=Count('like'),
        avg_likes=Avg('like')
    ).order_by('-total_likes')
    
    # Convert category stats to lists for the chart
    categories = [item['category'] or 'Uncategorized' for item in category_stats]
    likes_count = [item['total_likes'] for item in category_stats]
    
    # Overall statistics
    total_posts = posts.count()
    total_likes = sum(item['total_likes'] for item in category_stats)
    avg_likes_per_post = total_likes / total_posts if total_posts > 0 else 0
    
    # Get most liked posts
    most_liked_posts = posts.annotate(like_count=Count('like')).order_by('-like_count')[:5]
    
    # Get recent comments
    recent_comments = Comment.objects.filter(post__author=request.user).select_related('post', 'user').order_by('-created_at')[:5]
    
    # Engagement rate (simplified as likes per post)
    engagement_rate = (total_likes / (total_posts or 1)) * 100  # Avoid division by zero
    
    return render(request, 'analytics.html', {
        'categories': json.dumps(categories),
        'likes_count': json.dumps(likes_count),
        'total_posts': total_posts,
        'total_likes': total_likes,
        'avg_likes_per_post': round(avg_likes_per_post, 1),
        'most_liked_posts': most_liked_posts,
        'recent_comments': recent_comments,
        'engagement_rate': round(engagement_rate, 1)
    })

@csrf_exempt
@require_POST
@login_required
def like_toggle(request, post_id):
    post = get_object_or_404(BlogPost, id=post_id)
    like, created = Like.objects.get_or_create(user=request.user, post=post)
    if not created:
        like.delete()
        liked = False
    else:
        liked = True
    likes_count = post.like_set.count()
    return JsonResponse({'liked': liked, 'likes_count': likes_count})

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth import logout
from .forms import CommentForm
from django.contrib.auth import update_session_auth_hash
from .models import BlogPost, Like, UserProfile
from .forms import UserProfileForm, PasswordChangeForm

@login_required
def profile(request):
    return render(request, 'profile.html')

@login_required
def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, 'Your password was successfully updated!')
            return redirect('profile')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'change_password.html', {'form': form})

def post_detail(request, post_id):
    post = get_object_or_404(BlogPost, id=post_id)
    comments = post.comments.all()
    comment_form = None
    
    # Only show comment form to authenticated users
    if request.user.is_authenticated:
        if request.method == 'POST':
            comment_form = CommentForm(request.POST)
            if comment_form.is_valid():
                # Create and save the comment manually
                comment = Comment.objects.create(
                    post=post,
                    user=request.user,
                    text=comment_form.cleaned_data['text']
                )
                return redirect('post_detail', post_id=post_id)
        else:
            comment_form = CommentForm()
    
    # Increment view count
    if not request.session.get(f'viewed_post_{post_id}'):
        post.views += 1
        post.save(update_fields=['views'])
        request.session[f'viewed_post_{post_id}'] = True
    
    return render(request, 'post_detail.html', {
        'post': post,
        'comments': comments,
        'comment_form': comment_form,
        'user_can_comment': request.user.is_authenticated
    })

@login_required
def delete_post(request, post_id):
    post = get_object_or_404(BlogPost, id=post_id, author=request.user)
    post.delete()
    messages.success(request, 'Post deleted successfully')
    return redirect('my_posts')

@login_required
def edit_profile(request):
    try:
        profile = request.user.profile
    except UserProfile.DoesNotExist:
        profile = UserProfile.objects.create(user=request.user)
    
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully')
            return redirect('profile')
    else:
        form = UserProfileForm(instance=profile)
    return render(request, 'edit_profile.html', {'form': form})

@login_required
def logout_view(request):
    logout(request)
    return redirect('index')

@login_required
def edit_post(request, post_id):
    post = get_object_or_404(BlogPost, id=post_id, author=request.user)
    if request.method == 'POST':
        form = BlogPostForm(request.POST, request.FILES, instance=post)
        if form.is_valid():
            form.save()
            messages.success(request, 'Post updated successfully')
            return redirect('my_posts')
    else:
        form = BlogPostForm(instance=post)
    return render(request, 'edit_post.html', {'form': form, 'post': post})

@login_required
def delete_post(request, post_id):
    post = get_object_or_404(BlogPost, id=post_id, author=request.user)
    if request.method == 'POST':
        post.delete()
        messages.success(request, 'Post deleted successfully')
        return redirect('my_posts')
    return redirect('my_posts')

@login_required
def liked_posts(request):
    liked_post_ids = Like.objects.filter(user=request.user).values_list('post_id', flat=True)
    posts = BlogPost.objects.filter(id__in=liked_post_ids)
    return render(request, 'liked_posts.html', {'posts': posts})

@login_required
@require_POST
def add_comment(request, post_id):
    if request.method == 'POST' and request.user.is_authenticated:
        post = get_object_or_404(BlogPost, id=post_id)
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.post = post
            comment.user = request.user
            comment.save()
            avatar_url = None
            if hasattr(comment.user, 'profile') and getattr(comment.user.profile, 'profile_picture', None):
                avatar_url = comment.user.profile.profile_picture.url
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': True,
                    'comment': {
                        'id': comment.id,
                        'text': comment.text,
                        'created_at': comment.created_at.strftime('%B %d, %Y'),
                        'user': {
                            'username': comment.user.username,
                            'avatar': avatar_url
                        }
                    }
                })
        else:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': False, 'error': form.errors.as_json()})
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({'success': False, 'error': 'Invalid form data'})
    return redirect('post_detail', post_id=post_id)

@login_required
def delete_comment(request, comment_id):
    comment = get_object_or_404(Comment, id=comment_id, user=request.user)
    post_id = comment.post.id
    comment.delete()
    messages.success(request, 'Comment deleted successfully.')
    return redirect('post_detail', post_id=post_id)

import folium
from django.shortcuts import render


def map_view(request):
    # Center on Dhaka
    m = folium.Map(location=[23.8103, 90.4125], zoom_start=12)

    # Define top vlogging spots
    spots = [
        ("Lalbagh Fort", 23.7196, 90.3880),
        ("Hatirjheel", 23.7529, 90.4068),
        ("Ahsan Manzil", 23.7086, 90.4074),
        ("Dhanmondi Lake", 23.7415, 90.3725),
        ("Ramna Park", 23.7392, 90.4010),
    ]

    # Add pins for each spot
    for name, lat, lon in spots:
        folium.Marker([lat, lon], popup=name, icon=folium.Icon(color='green')).add_to(m)

    # Save as HTML inside templates folder
    m.save("templates/vlog_spots.html")
    return render(request, "vlog_spots.html")
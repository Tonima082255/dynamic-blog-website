from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/', views.profile, name='profile'),
    path('profile/edit/', views.edit_profile, name='edit_profile'),
    path('profile/change-password/', views.change_password, name='change_password'),
    path('post/<int:post_id>/', views.post_detail, name='post_detail'),
    path('post/<int:post_id>/delete/', views.delete_post, name='delete_post'),
    path('about/', views.about, name='about'),
    path('explore/', views.explore, name='explore'), 
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('dashboard/', views.dashboard, name='dashboard'),
    # path('create-post/', views.create_post, name='create_post'),
    path('create/', views.create_post, name='create_post'),
    path('vlog/upload/', views.upload_vlog, name='upload_vlog'),
    path('myposts/', views.my_posts, name='my_posts'),
    path('comments/', views.view_comments, name='view_comments'),
    path('analytics/', views.analytics, name='analytics'),
    path('post/<int:post_id>/like-toggle/', views.like_toggle, name='like_toggle'),
    path('post/<int:post_id>/add-comment/', views.add_comment, name='add_comment'),
    path('comment/<int:comment_id>/delete/', views.delete_comment, name='delete_comment'),
    path('post/<int:post_id>/edit/', views.edit_post, name='edit_post'),
    path('post/<int:post_id>/delete/', views.delete_post, name='delete_post'),
    path('liked-posts/', views.liked_posts, name='liked_posts'),
    path("vlog-map/", views.map_view, name="vlog_map"),
]

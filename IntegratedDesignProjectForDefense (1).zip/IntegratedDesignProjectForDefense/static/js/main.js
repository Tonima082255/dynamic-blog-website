// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Like button functionality
document.querySelectorAll('.like-btn').forEach(button => {
    button.addEventListener('click', function(e) {
        e.preventDefault();
        const postId = this.dataset.postId;
        const likeCount = document.getElementById(`like-count-${postId}`);
        const currentCount = parseInt(likeCount.textContent);
        
        // Toggle like state
        this.classList.toggle('liked');
        
        // Update count
        likeCount.textContent = this.classList.contains('liked') 
            ? currentCount + 1 
            : currentCount - 1;
        
        // Send AJAX request
        fetch(`/post/${postId}/like/`, {
            method: 'POST',
            headers: {
                'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: this.classList.contains('liked') ? 'like' : 'unlike'
            })
        });
    });
});

// Comment form handling
document.querySelectorAll('.comment-form').forEach(form => {
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        const postId = this.dataset.postId;
        const commentText = this.querySelector('textarea').value;
        
        // Add loading state
        this.querySelector('button').classList.add('loading');
        
        // Send AJAX request
        fetch(`/post/${postId}/comment/`, {
            method: 'POST',
            headers: {
                'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                text: commentText
            })
        })
        .then(response => response.json())
        .then(data => {
            // Add new comment to DOM
            const commentsList = document.querySelector(`#comments-${postId}`);
            const commentHtml = `
                <div class="comment-item bg-surface rounded-lg p-4 mb-4">
                    <div class="flex items-start gap-4">
                        <div class="comment-avatar w-10 h-10 rounded-full flex items-center justify-center">
                            ${data.username.charAt(0).toUpperCase()}
                        </div>
                        <div>
                            <div class="flex items-center gap-2 mb-2">
                                <span class="font-semibold">${data.username}</span>
                                <span class="text-text-secondary text-sm">${data.timestamp}</span>
                            </div>
                            <p class="text-text-secondary">${data.text}</p>
                        </div>
                    </div>
                </div>
            `;
            commentsList.insertAdjacentHTML('beforeend', commentHtml);
            
            // Reset form
            this.reset();
            
            // Remove loading state
            this.querySelector('button').classList.remove('loading');
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to post comment. Please try again.');
        });
    });
});

// Form validation
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function(e) {
        const requiredFields = this.querySelectorAll('[required]');
        let isValid = true;
        
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                isValid = false;
                field.classList.add('border-red-500');
            } else {
                field.classList.remove('border-red-500');
            }
        });
        
        if (!isValid) {
            e.preventDefault();
            alert('Please fill in all required fields.');
        }
    });
});

// Theme toggle
const themeToggle = document.querySelector('.theme-toggle');
if (themeToggle) {
    themeToggle.addEventListener('click', function() {
        document.documentElement.classList.toggle('dark');
        localStorage.setItem('theme', 
            document.documentElement.classList.contains('dark') ? 'dark' : 'light'
        );
    });
}

// Apply saved theme
const savedTheme = localStorage.getItem('theme');
if (savedTheme) {
    document.documentElement.classList.toggle('dark', savedTheme === 'dark');
}
